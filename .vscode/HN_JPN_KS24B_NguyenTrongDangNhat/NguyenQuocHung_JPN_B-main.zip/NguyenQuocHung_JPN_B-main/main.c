#include <stdio.h>
#include <string.h>
#include "menu.h"
#include "data.h"

int checkPass(char *email, char *password) {
    return strcmp(email, "admin") == 0 && strcmp(password, "admin123") == 0;
}

void adminDashboard() {
    int choose;
    do {
        adminMenu();
        scanf("%d", &choose);
        system("cls");

        switch (choose) {
            case 1:
                storeDashboard();  
                break;
            case 2:
                storeMenuSanPham();
                break;
            case 3:
                printf("Thoat khoi Admin.\n");
                return;
            default:
                printf("Lua chon khong hop li.\n");
                break;
        }
    } while (choose != 3);
}

void storeDashboard() {
    int choose;
    do {
        storeMenu();
        scanf("%d", &choose);

        switch (choose) {
            case 1:
                showProductList();  
                break;
            case 2:
                {
                    Product newProduct;
                    int idExists;
                    do {
                        idExists = 0;
                        printf("Nhap ID san pham: ");
                        scanf("%d", &newProduct.id);
                        for (int i = 0; i < numberProduct; i++) {
                            if (products[i].id == newProduct.id) {
                                printf("ID san pham da ton tai, vui long nhap ID khac!\n");
                                idExists = 1;
                                break; 
                            }
                        }
                    } while (idExists);
                    printf("Nhap ten san pham: ");
                    scanf("%s", newProduct.name);
                    addProduct(newProduct);
                    showProductList(); 
                }
                break;
            case 3:
                {
                    char searchName[100];
                    printf("Nhap ten san pham muon tim: ");
                    scanf("%s", searchName);
                    int found = 0;
                    printf("Ket qua tim kiem:\n");
                    printf("==============================================\n");
                    printf("| %-5s | %-20s |\n", "ID", "Name");
                    printf("==============================================\n");

                    for (int i = 0; i < numberProduct; i++) {
                        if (strstr(products[i].name, searchName) != NULL) {
                            printf("| %-5d | %-20s |\n", 
                                   products[i].id, products[i].name);
                            found = 1;
                        }
                    }

                    if (!found) {
                        printf("Khong tim thay san pham nao khop voi '%s'.\n", searchName);
                    }
                    printf("==============================================\n");
                }
                break;
            case 4:
                {
                    int idToEdit;
                    printf("Nhap ID san pham muon sua: ");
                    scanf("%d", &idToEdit);

                    int found = 0;
                    for (int i = 0; i < numberProduct; i++) {
                        if (products[i].id == idToEdit) {
                            found = 1;
                            printf("San pham hien tai:\n");
                            printf("ID: %d\n", products[i].id);
                            printf("Ten: %s\n", products[i].name);

                            printf("Nhap ten moi: ");
                            scanf("%s", products[i].name);

                            printf("San pham da duoc cap nhat.\n");
                            break;
                        }
                    }

                    if (!found) {
                        printf("ID san pham khong ton tai.\n");
                    }

                    showProductList();  
                }
                break;
            case 5:
                {
                    int idToDelete;
                    printf("Nhap ID san pham muon xoa: ");
                    scanf("%d", &idToDelete);

                    int found = 0;
                    int indexToDelete = -1;

                    for (int i = 0; i < numberProduct; i++) {
                        if (products[i].id == idToDelete) {
                            found = 1;
                            indexToDelete = i;
                            break;
                        }
                    }

                    if (!found) {
                        printf("San pham voi ID %d khong ton tai.\n", idToDelete);
                    } else {
                        char confirm;
                        printf("San pham co ID %d da ton tai. Ban co chac chan muon xoa? (Y/N): ", idToDelete);
                        scanf(" %c", &confirm);

                        if (confirm == 'Y' || confirm == 'y') {
                            for (int i = indexToDelete; i < numberProduct - 1; i++) {
                                products[i] = products[i + 1];
                            }
                            numberProduct--;
                            saveProductListToFile();  
                            printf("San pham da duoc xoa.\n");
                        } else {
                            printf("Xoa san pham bi huy.\n");
                        }
                    }

                    showProductList();  
                }
                break;
            case 6:
                {
                	for (int i = 0; i < numberProduct - 1; i++) {
                		for (int j = i + 1; j < numberProduct; j++) {
                			if (strcmp(products[i].name, products[j].name) > 0) {
                				Product temp = products[i];
                				products[i] = products[j];
                				products[j] = temp;
							}
						}
					}
					printf("Danh sach san pham da duoc sap xep theo Ten.\n");
					showProductList();
				}
                break;
            case 7:
                {
                	int id;
					char name[100];
					int valid = 0;
					do {
						valid = 1; 
						printf("Nhap ID danh muc (so duong): ");
						scanf("%d", &id);
						if (id <= 0) {
							printf("ID phai la so duong!\n");
							valid = 0;
							
						} else {
							for (int i = 0; i < numberProduct; i++) {
								if (products[i].id == id) {
									printf("ID danh muc da ton tai. Vui long nhap ID khac!\n");
									valid = 0;
									break; 
								}
							}
						} 
					} while (!valid); 
					do {
						valid = 1;
						printf("Nhap ten danh muc: ");
						scanf("%s", name);
						if (strlen(name) == 0) {
							printf("Ten danh muc khong duoc de trong!\n");
							valid = 0;
						} else {
							for (int i = 0; i < numberProduct; i++)  {
							if (strcmp(products[i].name, name) == 0) {
								printf("Ten danh muc da ton tai. Vui long nhap ten khac!\n");
								valid = 0;
								break; 
							}	
					      }
						} 
					} while (!valid);
					printf("Du lieu nhap hop le:\n");
					printf("ID: %d\n", id);
					printf("Ten danh muc: %s\n", name); 
					
					Product newProduct;
					newProduct.id = id;
					strcpy(newProduct.name, name);
					addProduct(newProduct);
					printf("Danh muc moi da duoc them vao danh sach.\n"); 
					showProductList();
                
				}
                break;
            case 8:
                printf("Thoat chuong trinh.\n");
                return;
            default:
                printf("Lua chon khong hop le.\n");
                break;
        }
    } while (choose != 8);
}


void storeMenuSanPham() {
	int choose;
	do {
		storeMenu2();
		scanf("%d", &choose);
		switch  (choose) {
			case 1:
				showProductList();
				break;
            case 2:
                {
                    Product newProduct;
                    int idExists;
                    do {
                        idExists = 0;
                        printf("Nhap ID san pham: ");
                        scanf("%d", &newProduct.id);
                        for (int i = 0; i < numberProduct; i++) {
                            if (products[i].id == newProduct.id) {
                                printf("ID san pham da ton tai, vui long nhap ID khac!\n");
                                idExists = 1;
                                break; 
                            }
                        }
                    } while (idExists);
                    printf("Nhap ten san pham: ");
                    scanf("%s", newProduct.name);
                    addProduct(newProduct);
                    showProductList(); 
                }
                break;
            case 3:
                {
                    int idToEdit;
                    printf("Nhap ID san pham muon sua: ");
                    scanf("%d", &idToEdit);

                    int found = 0;
                    for (int i = 0; i < numberProduct; i++) {
                        if (products[i].id == idToEdit) {
                            found = 1;
                            printf("San pham hien tai:\n");
                            printf("ID: %d\n", products[i].id);
                            printf("Ten: %s\n", products[i].name);

                            printf("Nhap ten moi: ");
                            scanf("%s", products[i].name);

                            printf("San pham da duoc cap nhat.\n");
                            break;
                        }
                    }

                    if (!found) {
                        printf("ID san pham khong ton tai.\n");
                    }

                    showProductList();  
                }
                break;
            case 4:
                {
                                     int idToDelete;
                    printf("Nhap ID san pham muon xoa: ");
                    scanf("%d", &idToDelete);

                    int found = 0;
                    int indexToDelete = -1;

                    for (int i = 0; i < numberProduct; i++) {
                        if (products[i].id == idToDelete) {
                            found = 1;
                            indexToDelete = i;
                            break;
                        }
                    }

                    if (!found) {
                        printf("San pham voi ID %d khong ton tai.\n", idToDelete);
                    } else {
                        char confirm;
                        printf("San pham co ID %d da ton tai. Ban co chac chan muon xoa? (Y/N): ", idToDelete);
                        scanf(" %c", &confirm);

                        if (confirm == 'Y' || confirm == 'y') {
                            for (int i = indexToDelete; i < numberProduct - 1; i++) {
                                products[i] = products[i + 1];
                            }
                            numberProduct--;
                            saveProductListToFile();  
                            printf("San pham da duoc xoa.\n");
                        } else {
                            printf("Xoa san pham bi huy.\n");
                        }
                    }

                    showProductList();  
                }
                break;
            case 5:
                {
                    char searchName[100];
                    printf("Nhap ten san pham muon tim: ");
                    scanf("%s", searchName);
                    int found = 0;
                    printf("Ket qua tim kiem:\n");
                    printf("================================\n");
                    printf("| %-5s | %-20s |\n", "ID", "Name");
                    printf("================================\n");

                    for (int i = 0; i < numberProduct; i++) {
                        if (strstr(products[i].name, searchName) != NULL) {
                            printf("| %-5d | %-20s |\n", 
                                   products[i].id, products[i].name);
                            found = 1;
                        }
                    }

                    if (!found) {
                        printf("Khong tim thay san pham nao khop voi '%s'.\n", searchName);
                    }
                    printf("================================\n");
                }
                break;
        
            case 9: 
                printf("Thoat chuong trinh.\n");
                return;
			default:
			    printf("Lua chon khong hop le.\n");
			    
		}
		
	} while (choose != 9); 
}



 
int main() {
    loadProductListFromFile();
    
    int choice;
    do {
        showMenu();
        scanf("%d", &choice);
        system("cls");
        if (choice == 1) {
            showLogin();
            char email[100], password[100];
            printf("Email: ");
            scanf("%s", email);
            printf("Password: ");
            scanf("%s", password);

            if (checkPass(email, password)) {
                adminDashboard();  
            } else {
                printf("Dang nhap khong thanh cong!\n");
            }
        } else if (choice == 2) {
            printf("Thoat khoi chuong trinh.\n");
            break;
        } else {
            printf("Lua chon khong hop le. Vui long chon lai.\n");
        }
    } while (choice != 2);

    return 0;
}

