#ifndef DATA_H
#define DATA_H

#define MAX_PRODUCT 100  

typedef struct {
    int id;                
    char name[100];
} product;

void showproductList(void);            
void addproduct(product newproduct);  
void saveproductListToFile(void);     
void loadproductListFromFile(void);    

extern product product[MAX_PRODUCT]; 
extern int numberproduct;             

#endif
