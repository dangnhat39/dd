#ifndef MENU_H
#define MENU_H

// Cac ham hien thi menu
void showMenu(void);                
void showLogin(void);              
void showLoginStore(void);          
void adminMenu(void);              
void storeMenu(void);              

#endif
