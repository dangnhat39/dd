#include <stdio.h>
#include <string.h>
#include "data.h"

Product products[MAX_PRODUCTS];  
int numberProduct = 5;           

// Ham doc danh sach san pham tu file
void loadProductListFromFile(void) {
    FILE *file = fopen("danhSach.bin", "rb");
    if (file != NULL) {
        fread(&numberProduct, sizeof(int), 1, file); 
        fread(products, sizeof(Product), numberProduct, file); 
        fclose(file);
    }
}

void saveProductListToFile(void) {
    FILE *file = fopen("danhSach.bin", "wb");
    if (file != NULL) {
        fwrite(&numberProduct, sizeof(int), 1, file);  
        fwrite(products, sizeof(Product), numberProduct, file); 
        fclose(file);
    }
}

void showProductList(void) {
    printf("Danh sach san pham:\n");
    printf("================================\n");
    printf("| %-5s | %-20s |\n", "ID", "Name");
    printf("================================\n");

    for (int i = 0; i < numberProduct; i++) {
        printf("| %-5d | %-20s |\n", 
               products[i].id, products[i].name);
    }

    printf("================================\n");
}

void addProduct(Product newProduct) {
    if (numberProduct < MAX_PRODUCTS) {
        products[numberProduct] = newProduct;
        numberProduct++;
        saveProductListToFile();  
    } else {
        printf("Danh sach san pham da day.\n");
    }
}
