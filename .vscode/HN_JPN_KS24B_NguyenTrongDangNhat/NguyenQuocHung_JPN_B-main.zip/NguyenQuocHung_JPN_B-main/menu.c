#include <stdio.h>
#include "menu.h"
#include "data.h"

void showMenu(void) {
    printf("**** Store Management System Using C ****\n");
    printf("\n");
    printf("          CHOOSE YOUR ROLE\n");
    printf("      =========================\n");
    printf("      [1] Dang nhap Admin.\n");
    printf("      [2] Thoat.\n");
    printf("      =========================\n");
    printf("      Nhap lua chon: ");
}

void showLogin(void) {
    printf("**** Store Management System Using C ****\n");
    printf("                 ADMIN\n");
    printf("          ==================\n");
    printf("                 LOGIN\n");
    printf("          ==================\n");
    printf("            Account: admin\n");
    printf("            Password: admin123\n");
}

void adminMenu(void) {
    printf("**** Store Management System Using C ****\n");
    printf("\n");
    printf("                MENU\n");
    printf("          ==================\n");
    printf("       [1] Quan ly danh muc\n");
    printf("       [2] Quan ly san pham\n");
    printf("       [3] Thoat khoi chuong trinh\n");
    printf("          ==================\n");
    printf("       Nhap lua chon: ");
}

void storeMenu(void) {
    printf("**** Store Management System Using C ****\n");
    printf("\n");
    printf("                MENU\n");
    printf("          ==================\n");
    printf("       [1] Hien thi danh sach danh muc\n");
    printf("       [2] Them danh muc moi\n");
    printf("       [3] Tim kiem thong tin danh muc\n");
    printf("       [4] Sua thong tin danh muc\n");
    printf("       [5] Nhap id danh muc muon xoa\n");
    printf("       [6] Sap xep danh sach danh muc\n");
    printf("       [7] Kiem tra du lieu nhap cho danh muc\n");
    printf("       [8] Thoat chuong trinh\n");
    printf("          ==================\n");
    printf("       Nhap lua chon: ");
}
void storeMenu2(void) {
	printf("**** Store Management System Using C ****\n");
    printf("\n");
    printf("                MENU\n");
    printf("          ==================\n");
    printf("       [1] Hien thi danh sach san pham\n");
    printf("       [2] Them san pham\n");
    printf("       [3] Sua thong tin san pham\n");
    printf("       [4] Xoa san pham\n");
    printf("       [5] Tim kiem san pham theo ten\n");
    printf("       [6] Sap xep san pham theo gia tien\n");
    printf("       [7] Loc san pham\n");
    printf("       [8] Kiem tra du lieu nhap cho san pham\n");
    printf("       [9] Thoat chuong trinh\n");
    printf("          ==================\n");
    printf("       Nhap lua chon: ");

}

