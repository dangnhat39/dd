#include <stdio.h>
#include <string.h>
#include "data.h"

int numberproduct = 5;

void loadproductListFromFile(void) {
    FILE *file = fopen("product.bin", "rb");
    if (file != NULL) {
        fread(&numberproduct, sizeof(int), 1, file);
        fread(product, sizeof(product), numberproduct, file);
        fclose(file);
    } else {
        printf("Khong the mo file de doc.\n");
    }
}

void saveproductListToFile(void) {
    FILE *file = fopen("product.bin", "wb");
    if (file != NULL) {
        fwrite(&numberproduct, sizeof(int), 1, file);
        fwrite(product, sizeof(product), numberproduct, file);
        fclose(file);
    } else {
        printf("Khong the mo file de ghi.\n");
    }
}

void showproductList(void) {
    printf("Danh sach san pham:\n");
    printf("================================\n");
    printf("| %-5s | %-20s |\n", "ID", "Name");
    printf("================================\n");

    for (int i = 0; i < numberproduct; i++) {
        printf("| %-5d | %-20s |\n", product[i].id, product[i].name);
    }

    printf("================================\n");
}

void addproduct(product newproduct) {
    if (numberproduct < MAX_PRODUCT) {
        product[numberproduct] = newproduct;
        numberproduct++;
        saveproductListToFile();
    } else {
        printf("Danh sach san pham da day.\n");
    }
}

