#ifndef DATA_H
#define DATA_H

#define MAX_PRODUCTS 100  

typedef struct {
    int id;                
    char name[100];
} Product;

void showProductList(void);            
void addProduct(Product newProduct);  
void saveProductListToFile(void);     
void loadProductListFromFile(void);    

extern Product products[MAX_PRODUCTS]; 
extern int numberProduct;             

#endif
